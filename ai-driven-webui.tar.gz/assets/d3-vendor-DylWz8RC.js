import"./vendor-CR66K9Ud.js";
